package com.example.batterytest

import android.content.Context
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.batterytest.ui.theme.BatteryTestTheme
import android.Manifest
import android.content.Context.BATTERY_SERVICE
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BatteryTestTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    getBatteryLevel(LocalContext.current)
                }
            }
        }
    }
}

@Composable
fun getBatteryLevel(context: Context) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(all = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = "Battery Level Indicator",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = Color.Green,
        )
        
        val batteryManager = context.getSystemService(BATTERY_SERVICE) as BatteryManager
        val batLevel: Int = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        val ipState = remember { mutableStateOf("192.168.0.4")}
        Text("IP-address: ")
        TextField(
            value = ipState.value,
            onValueChange = { ipState.value = it }
        )

        val portState = remember { mutableStateOf("1234")}
        Text ( "Port: " )
        TextField(
            value = portState.value,
            onValueChange = { portState.value = it }
        )

        Button(
            onClick = { val thread = Thread {
                sendUDPPacket("test", ipState.value, portState.value)
            }
                thread.start()
            }
        ) {
            Text(text= "Send test packet")
        }

        val timer = Timer()
        timer.schedule(object : TimerTask() {
            override fun run() {
                val thread = Thread {
                    sendBatDecision(batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY), ipState.value, portState.value)
                }
                thread.start()
            }
        }, 0, 1800000)
    }
}

fun sendUDPPacket(message: String, ipAddress: String, port: String) {
    val socket = DatagramSocket()
    val address = InetAddress.getByName(ipAddress)
    val data = message.toByteArray()
    val packet = DatagramPacket(data,data.size, address, port.toInt())
    socket.send(packet)
    socket.close()
}

fun sendBatDecision(batLevel: Int, ipAddress: String, port: String) {
    if (batLevel >= 80) {
        sendUDPPacket("0", ipAddress, port)
    } else if (batLevel < 70) {
        sendUDPPacket("1", ipAddress, port)
    }
}